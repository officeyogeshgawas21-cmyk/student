namespace WMS_AVG.Services
{
    public interface IPhotoStorage
    {
        /// <summary>Returns an error message if the upload is not an acceptable photo, otherwise null.</summary>
        string? Validate(IFormFile? file);

        /// <summary>Saves the photo under wwwroot/uploads/{folder} and returns its web path.</summary>
        Task<string> SaveAsync(IFormFile file, string folder, CancellationToken cancellationToken = default);

        /// <summary>Deletes a previously saved photo. Ignores null, missing files and foreign paths.</summary>
        void Delete(string? webPath);
    }

    public class PhotoStorage : IPhotoStorage
    {
        public const long MaxBytes = 5 * 1024 * 1024; // 5 MB
        private const string UrlPrefix = "/uploads/";

        private static readonly HashSet<string> AllowedExtensions =
            new(StringComparer.OrdinalIgnoreCase) { ".jpg", ".jpeg", ".png", ".webp" };

        private readonly string _root;

        public PhotoStorage(IWebHostEnvironment env)
        {
            var webRoot = env.WebRootPath ?? Path.Combine(env.ContentRootPath, "wwwroot");
            _root = Path.GetFullPath(Path.Combine(webRoot, "uploads"));
        }

        public string? Validate(IFormFile? file)
        {
            if (file is null || file.Length == 0)
            {
                return null; // nothing uploaded
            }

            if (file.Length > MaxBytes)
            {
                return "Photo must be 5 MB or smaller.";
            }

            var extension = Path.GetExtension(file.FileName);
            if (!AllowedExtensions.Contains(extension))
            {
                return "Only JPG, PNG or WebP photos are allowed.";
            }

            // Check the real file signature, not just the name the browser sent.
            var header = new byte[12];
            int read;
            using (var stream = file.OpenReadStream())
            {
                read = stream.Read(header, 0, header.Length);
            }

            return LooksLikeImage(header, read) ? null : "That file is not a valid JPG, PNG or WebP image.";
        }

        public async Task<string> SaveAsync(IFormFile file, string folder, CancellationToken cancellationToken = default)
        {
            var directory = Path.Combine(_root, folder);
            Directory.CreateDirectory(directory);

            var fileName = Guid.NewGuid().ToString("N") + Path.GetExtension(file.FileName).ToLowerInvariant();
            var fullPath = Path.Combine(directory, fileName);

            await using (var target = new FileStream(fullPath, FileMode.CreateNew))
            {
                await file.CopyToAsync(target, cancellationToken);
            }

            return $"{UrlPrefix}{folder}/{fileName}";
        }

        public void Delete(string? webPath)
        {
            if (string.IsNullOrWhiteSpace(webPath) || !webPath.StartsWith(UrlPrefix, StringComparison.Ordinal))
            {
                return;
            }

            var relative = webPath.Substring(UrlPrefix.Length).Replace('/', Path.DirectorySeparatorChar);
            var fullPath = Path.GetFullPath(Path.Combine(_root, relative));

            // Never delete anything outside the uploads folder.
            if (!fullPath.StartsWith(_root + Path.DirectorySeparatorChar, StringComparison.Ordinal))
            {
                return;
            }

            try
            {
                File.Delete(fullPath);
            }
            catch (IOException)
            {
                // A locked or already-removed file should not break the request.
            }
        }

        private static bool LooksLikeImage(byte[] h, int length)
        {
            if (length >= 3 && h[0] == 0xFF && h[1] == 0xD8 && h[2] == 0xFF)
            {
                return true; // JPEG
            }

            if (length >= 8 && h[0] == 0x89 && h[1] == 0x50 && h[2] == 0x4E && h[3] == 0x47)
            {
                return true; // PNG
            }

            return length >= 12
                && h[0] == (byte)'R' && h[1] == (byte)'I' && h[2] == (byte)'F' && h[3] == (byte)'F'
                && h[8] == (byte)'W' && h[9] == (byte)'E' && h[10] == (byte)'B' && h[11] == (byte)'P'; // WebP
        }
    }
}
