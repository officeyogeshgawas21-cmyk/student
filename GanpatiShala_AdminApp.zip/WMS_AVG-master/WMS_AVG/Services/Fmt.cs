using System.Globalization;

namespace WMS_AVG.Services
{
    /// <summary>Small formatting helpers shared by the Razor views.</summary>
    public static class Fmt
    {
        private static readonly CultureInfo Indian = ResolveIndianCulture();

        /// <summary>Formats an amount as rupees with Indian digit grouping, e.g. ₹1,25,000.</summary>
        public static string Money(decimal amount) => "₹" + amount.ToString("#,##0.##", Indian);

        /// <summary>Formats a height like "5 ft" or "2.5 ft".</summary>
        public static string Feet(decimal size) => size.ToString("0.##", CultureInfo.InvariantCulture) + " ft";

        private static CultureInfo ResolveIndianCulture()
        {
            try
            {
                return CultureInfo.GetCultureInfo("en-IN");
            }
            catch (CultureNotFoundException)
            {
                return CultureInfo.InvariantCulture;
            }
        }
    }
}
