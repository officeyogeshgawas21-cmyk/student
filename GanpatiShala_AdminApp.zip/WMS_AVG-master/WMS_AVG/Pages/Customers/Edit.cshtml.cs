using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WMS_AVG.Data;
using WMS_AVG.Models;
using WMS_AVG.Services;

namespace WMS_AVG.Pages.Customers
{
    /// <summary>Adds a customer (no id in the URL) or edits an existing one.</summary>
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        private readonly IPhotoStorage _photos;

        public EditModel(ApplicationDbContext db, IPhotoStorage photos)
        {
            _db = db;
            _photos = photos;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public int? Id { get; private set; }
        public string? LastYearPhotoPath { get; private set; }
        public string? CurrentYearPhotoPath { get; private set; }

        public class InputModel
        {
            [Required, StringLength(100)]
            [Display(Name = "Customer name")]
            public string Name { get; set; } = string.Empty;

            [Required, StringLength(300)]
            public string Address { get; set; } = string.Empty;

            [Required, StringLength(20)]
            [RegularExpression(@"^[0-9+\-\s()]{7,20}$", ErrorMessage = "Enter a valid contact number.")]
            public string Contact { get; set; } = string.Empty;

            public IFormFile? LastYearPhoto { get; set; }

            public IFormFile? CurrentYearPhoto { get; set; }
        }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            Id = id;
            if (id is null)
            {
                return Page();
            }

            var customer = await _db.Customers.FindAsync(id.Value);
            if (customer is null)
            {
                return NotFound();
            }

            Input = new InputModel
            {
                Name = customer.Name,
                Address = customer.Address,
                Contact = customer.Contact
            };
            LastYearPhotoPath = customer.LastYearPhotoPath;
            CurrentYearPhotoPath = customer.CurrentYearPhotoPath;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            Id = id;

            Customer? customer = null;
            if (id is not null)
            {
                customer = await _db.Customers.FindAsync(id.Value);
                if (customer is null)
                {
                    return NotFound();
                }
            }

            AddPhotoError(Input.LastYearPhoto, nameof(Input.LastYearPhoto));
            AddPhotoError(Input.CurrentYearPhoto, nameof(Input.CurrentYearPhoto));

            if (!ModelState.IsValid)
            {
                LastYearPhotoPath = customer?.LastYearPhotoPath;
                CurrentYearPhotoPath = customer?.CurrentYearPhotoPath;
                return Page();
            }

            var isNew = customer is null;
            customer ??= new Customer();

            customer.Name = Input.Name.Trim();
            customer.Address = Input.Address.Trim();
            customer.Contact = Input.Contact.Trim();

            string? replacedLastYear = null;
            string? replacedCurrent = null;

            if (Input.LastYearPhoto is { Length: > 0 })
            {
                replacedLastYear = customer.LastYearPhotoPath;
                customer.LastYearPhotoPath = await _photos.SaveAsync(Input.LastYearPhoto, "customers");
            }

            if (Input.CurrentYearPhoto is { Length: > 0 })
            {
                replacedCurrent = customer.CurrentYearPhotoPath;
                customer.CurrentYearPhotoPath = await _photos.SaveAsync(Input.CurrentYearPhoto, "customers");
            }

            if (isNew)
            {
                _db.Customers.Add(customer);
            }

            await _db.SaveChangesAsync();

            // Only remove the old files once the new paths are safely stored.
            _photos.Delete(replacedLastYear);
            _photos.Delete(replacedCurrent);

            TempData["Message"] = isNew
                ? $"Customer \"{customer.Name}\" was added."
                : $"Customer \"{customer.Name}\" was updated.";
            return RedirectToPage("Index");
        }

        private void AddPhotoError(IFormFile? file, string propertyName)
        {
            var error = _photos.Validate(file);
            if (error is not null)
            {
                ModelState.AddModelError($"{nameof(Input)}.{propertyName}", error);
            }
        }
    }
}
