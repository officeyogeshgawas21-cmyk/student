using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WMS_AVG.Data;
using WMS_AVG.Models;
using WMS_AVG.Services;

namespace WMS_AVG.Pages.Customers
{
    public class IndexModel : PageModel
    {
        private const int PageSize = 10;

        private readonly ApplicationDbContext _db;
        private readonly IPhotoStorage _photos;

        public IndexModel(ApplicationDbContext db, IPhotoStorage photos)
        {
            _db = db;
            _photos = photos;
        }

        [BindProperty(SupportsGet = true)]
        public string? Q { get; set; }

        [BindProperty(SupportsGet = true)]
        public int PageNo { get; set; } = 1;

        public List<Customer> Customers { get; private set; } = new();
        public int TotalCount { get; private set; }
        public int TotalPages => Math.Max(1, (int)Math.Ceiling(TotalCount / (double)PageSize));

        public async Task OnGetAsync()
        {
            var query = _db.Customers.AsNoTracking();

            var term = Q?.Trim();
            if (!string.IsNullOrEmpty(term))
            {
                query = query.Where(c =>
                    c.Name.Contains(term) || c.Contact.Contains(term) || c.Address.Contains(term));
            }

            TotalCount = await query.CountAsync();
            PageNo = Math.Clamp(PageNo, 1, TotalPages);

            Customers = await query
                .OrderBy(c => c.Name)
                .Skip((PageNo - 1) * PageSize)
                .Take(PageSize)
                .ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var customer = await _db.Customers.FindAsync(id);
            if (customer is not null)
            {
                _db.Customers.Remove(customer);
                await _db.SaveChangesAsync();

                _photos.Delete(customer.LastYearPhotoPath);
                _photos.Delete(customer.CurrentYearPhotoPath);
                TempData["Message"] = $"Customer \"{customer.Name}\" was deleted.";
            }

            return RedirectToPage();
        }
    }
}
