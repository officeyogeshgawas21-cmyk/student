using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WMS_AVG.Data;
using WMS_AVG.Models;

namespace WMS_AVG.Pages
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _db;

        public IndexModel(ApplicationDbContext db)
        {
            _db = db;
        }

        public int TotalCustomers { get; private set; }
        public int CustomersWithCurrentPhoto { get; private set; }
        public int CustomersMissingCurrentPhoto => TotalCustomers - CustomersWithCurrentPhoto;
        public int TotalIdols { get; private set; }
        public int AvailableIdols { get; private set; }
        public decimal AvailableValue { get; private set; }

        public List<Customer> RecentCustomers { get; private set; } = new();
        public List<Idol> RecentIdols { get; private set; } = new();
        public List<SizeBucket> BySize { get; private set; } = new();

        public record SizeBucket(decimal Size, int Count);

        public async Task OnGetAsync()
        {
            TotalCustomers = await _db.Customers.CountAsync();
            CustomersWithCurrentPhoto = await _db.Customers
                .CountAsync(c => c.CurrentYearPhotoPath != null && c.CurrentYearPhotoPath != "");

            TotalIdols = await _db.Idols.CountAsync();
            AvailableIdols = await _db.Idols.CountAsync(i => i.IsAvailable);
            AvailableValue = await _db.Idols
                .Where(i => i.IsAvailable)
                .SumAsync(i => (decimal?)i.Price) ?? 0m;

            RecentCustomers = await _db.Customers
                .AsNoTracking()
                .OrderByDescending(c => c.CreatedOn)
                .Take(5)
                .ToListAsync();

            RecentIdols = await _db.Idols
                .AsNoTracking()
                .OrderByDescending(i => i.CreatedOn)
                .Take(4)
                .ToListAsync();

            BySize = await _db.Idols
                .Where(i => i.IsAvailable)
                .GroupBy(i => i.SizeInFeet)
                .OrderBy(g => g.Key)
                .Select(g => new SizeBucket(g.Key, g.Count()))
                .ToListAsync();
        }
    }
}
