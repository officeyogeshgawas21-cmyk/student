using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using WMS_AVG.Data;
using WMS_AVG.Models;
using WMS_AVG.Services;

namespace WMS_AVG.Pages.Gallery
{
    public class IndexModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        private readonly IPhotoStorage _photos;

        public IndexModel(ApplicationDbContext db, IPhotoStorage photos)
        {
            _db = db;
            _photos = photos;
        }

        [BindProperty(SupportsGet = true)]
        public string? Q { get; set; }

        /// <summary>"", "available" or "soldout".</summary>
        [BindProperty(SupportsGet = true)]
        public string? Status { get; set; }

        /// <summary>"", "price_asc", "price_desc", "size_asc" or "size_desc".</summary>
        [BindProperty(SupportsGet = true)]
        public string? Sort { get; set; }

        public List<Idol> Idols { get; private set; } = new();

        public async Task OnGetAsync()
        {
            var query = _db.Idols.AsNoTracking();

            var term = Q?.Trim();
            if (!string.IsNullOrEmpty(term))
            {
                query = query.Where(i => i.Name.Contains(term));
            }

            query = Status switch
            {
                "available" => query.Where(i => i.IsAvailable),
                "soldout" => query.Where(i => !i.IsAvailable),
                _ => query
            };

            query = Sort switch
            {
                "price_asc" => query.OrderBy(i => i.Price),
                "price_desc" => query.OrderByDescending(i => i.Price),
                "size_asc" => query.OrderBy(i => i.SizeInFeet).ThenBy(i => i.Price),
                "size_desc" => query.OrderByDescending(i => i.SizeInFeet).ThenBy(i => i.Price),
                _ => query.OrderByDescending(i => i.CreatedOn)
            };

            Idols = await query.ToListAsync();
        }

        public async Task<IActionResult> OnPostDeleteAsync(int id)
        {
            var idol = await _db.Idols.FindAsync(id);
            if (idol is not null)
            {
                _db.Idols.Remove(idol);
                await _db.SaveChangesAsync();

                _photos.Delete(idol.PhotoPath);
                TempData["Message"] = $"\"{idol.Name}\" was removed from the gallery.";
            }

            return RedirectToPage();
        }

        public async Task<IActionResult> OnPostToggleAsync(int id)
        {
            var idol = await _db.Idols.FindAsync(id);
            if (idol is not null)
            {
                idol.IsAvailable = !idol.IsAvailable;
                await _db.SaveChangesAsync();
                TempData["Message"] = $"\"{idol.Name}\" marked as {(idol.IsAvailable ? "available" : "sold out")}.";
            }

            return RedirectToPage(new { q = Q, status = Status, sort = Sort });
        }
    }
}
