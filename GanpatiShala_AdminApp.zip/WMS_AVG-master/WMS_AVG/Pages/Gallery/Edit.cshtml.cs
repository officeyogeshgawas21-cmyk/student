using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using WMS_AVG.Data;
using WMS_AVG.Models;
using WMS_AVG.Services;

namespace WMS_AVG.Pages.Gallery
{
    /// <summary>Adds an idol to the gallery (no id in the URL) or edits an existing one.</summary>
    public class EditModel : PageModel
    {
        private readonly ApplicationDbContext _db;
        private readonly IPhotoStorage _photos;

        public EditModel(ApplicationDbContext db, IPhotoStorage photos)
        {
            _db = db;
            _photos = photos;
        }

        [BindProperty]
        public InputModel Input { get; set; } = new();

        public int? Id { get; private set; }
        public string? PhotoPath { get; private set; }

        public class InputModel
        {
            [Required, StringLength(100)]
            [Display(Name = "Idol name")]
            public string Name { get; set; } = string.Empty;

            [StringLength(500)]
            public string? Description { get; set; }

            [Range(0.5, 50, ErrorMessage = "Enter a size between 0.5 and 50 feet.")]
            [Display(Name = "Size (feet)")]
            public decimal SizeInFeet { get; set; } = 3;

            [Range(0, 100000000, ErrorMessage = "Enter a valid price.")]
            [Display(Name = "Price (₹)")]
            public decimal Price { get; set; }

            [Display(Name = "Available for sale")]
            public bool IsAvailable { get; set; } = true;

            public IFormFile? Photo { get; set; }
        }

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            Id = id;
            if (id is null)
            {
                return Page();
            }

            var idol = await _db.Idols.FindAsync(id.Value);
            if (idol is null)
            {
                return NotFound();
            }

            Input = new InputModel
            {
                Name = idol.Name,
                Description = idol.Description,
                SizeInFeet = idol.SizeInFeet,
                Price = idol.Price,
                IsAvailable = idol.IsAvailable
            };
            PhotoPath = idol.PhotoPath;
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            Id = id;

            Idol? idol = null;
            if (id is not null)
            {
                idol = await _db.Idols.FindAsync(id.Value);
                if (idol is null)
                {
                    return NotFound();
                }
            }

            var photoError = _photos.Validate(Input.Photo);
            if (photoError is not null)
            {
                ModelState.AddModelError("Input.Photo", photoError);
            }
            else if (idol is null && Input.Photo is not { Length: > 0 })
            {
                ModelState.AddModelError("Input.Photo", "Please choose a photo of the idol.");
            }

            if (!ModelState.IsValid)
            {
                PhotoPath = idol?.PhotoPath;
                return Page();
            }

            var isNew = idol is null;
            idol ??= new Idol();

            idol.Name = Input.Name.Trim();
            idol.Description = string.IsNullOrWhiteSpace(Input.Description) ? null : Input.Description.Trim();
            idol.SizeInFeet = Input.SizeInFeet;
            idol.Price = Input.Price;
            idol.IsAvailable = Input.IsAvailable;

            string? replacedPhoto = null;
            if (Input.Photo is { Length: > 0 })
            {
                replacedPhoto = isNew ? null : idol.PhotoPath;
                idol.PhotoPath = await _photos.SaveAsync(Input.Photo, "idols");
            }

            if (isNew)
            {
                _db.Idols.Add(idol);
            }

            await _db.SaveChangesAsync();
            _photos.Delete(replacedPhoto);

            TempData["Message"] = isNew
                ? $"\"{idol.Name}\" was added to the gallery."
                : $"\"{idol.Name}\" was updated.";
            return RedirectToPage("Index");
        }
    }
}
