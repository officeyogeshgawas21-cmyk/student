// Live preview for photo pickers: <input type="file" data-preview="#imgId">
document.addEventListener("change", function (e) {
    var input = e.target;
    if (!(input instanceof HTMLInputElement) || input.type !== "file" || !input.dataset.preview) {
        return;
    }

    var img = document.querySelector(input.dataset.preview);
    var file = input.files && input.files[0];
    if (img && file) {
        img.src = URL.createObjectURL(file);
        img.classList.remove("d-none");
    }
});

// Confirm before destructive actions: <form data-confirm="Delete this?">
document.addEventListener("submit", function (e) {
    var form = e.target;
    if (form instanceof HTMLFormElement && form.dataset.confirm && !window.confirm(form.dataset.confirm)) {
        e.preventDefault();
    }
});
