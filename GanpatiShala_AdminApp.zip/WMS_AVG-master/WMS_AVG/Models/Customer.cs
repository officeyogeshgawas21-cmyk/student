using System.ComponentModel.DataAnnotations;

namespace WMS_AVG.Models
{
    /// <summary>A person who orders a Ganesh idol from the shala.</summary>
    public class Customer
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [Required, StringLength(300)]
        public string Address { get; set; } = string.Empty;

        [Required, StringLength(20)]
        public string Contact { get; set; } = string.Empty;

        /// <summary>Web path of last year's idol photo, e.g. /uploads/customers/abc.jpg</summary>
        [StringLength(260)]
        public string? LastYearPhotoPath { get; set; }

        /// <summary>Web path of this year's idol photo.</summary>
        [StringLength(260)]
        public string? CurrentYearPhotoPath { get; set; }

        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    }
}
