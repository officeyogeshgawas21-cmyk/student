using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace WMS_AVG.Models
{
    /// <summary>A ready-made / catalogue Ganesh idol shown in the gallery.</summary>
    public class Idol
    {
        public int Id { get; set; }

        [Required, StringLength(100)]
        public string Name { get; set; } = string.Empty;

        [StringLength(500)]
        public string? Description { get; set; }

        /// <summary>Height of the idol in feet (e.g. 2.5).</summary>
        [Column(TypeName = "decimal(5,2)")]
        public decimal SizeInFeet { get; set; }

        /// <summary>Price in rupees.</summary>
        [Column(TypeName = "decimal(18,2)")]
        public decimal Price { get; set; }

        public bool IsAvailable { get; set; } = true;

        [Required, StringLength(260)]
        public string PhotoPath { get; set; } = string.Empty;

        public DateTime CreatedOn { get; set; } = DateTime.UtcNow;
    }
}
