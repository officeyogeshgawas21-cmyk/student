using Microsoft.AspNetCore.Identity;

namespace WMS_AVG.Data
{
    public static class SeedData
    {
        public const string AdminRole = "Admin";

        /// <summary>
        /// Makes sure the Admin role exists and, if SeedAdmin:Email / SeedAdmin:Password are
        /// configured, that this admin account exists. Never overwrites an existing password.
        /// </summary>
        public static async Task InitializeAsync(IServiceProvider services, IConfiguration config)
        {
            var roles = services.GetRequiredService<RoleManager<IdentityRole>>();
            if (!await roles.RoleExistsAsync(AdminRole))
            {
                await roles.CreateAsync(new IdentityRole(AdminRole));
            }

            var email = config["SeedAdmin:Email"];
            var password = config["SeedAdmin:Password"];
            if (string.IsNullOrWhiteSpace(email) || string.IsNullOrWhiteSpace(password))
            {
                return;
            }

            var users = services.GetRequiredService<UserManager<IdentityUser>>();
            var user = await users.FindByEmailAsync(email);
            if (user is null)
            {
                user = new IdentityUser { UserName = email, Email = email, EmailConfirmed = true };
                var created = await users.CreateAsync(user, password);
                if (!created.Succeeded)
                {
                    var errors = string.Join("; ", created.Errors.Select(e => e.Description));
                    throw new InvalidOperationException($"Could not create the seed admin: {errors}");
                }
            }

            if (!await users.IsInRoleAsync(user, AdminRole))
            {
                await users.AddToRoleAsync(user, AdminRole);
            }
        }
    }
}
