using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using WMS_AVG.Data;
using WMS_AVG.Services;

var builder = WebApplication.CreateBuilder(args);

// Database
var connectionString = builder.Configuration.GetConnectionString("DefaultConnection")
    ?? throw new InvalidOperationException("Connection string 'DefaultConnection' not found.");
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(connectionString));
builder.Services.AddDatabaseDeveloperPageExceptionFilter();

// Identity: admin-only application. Accounts are created by the seed step (or by an admin),
// so email confirmation is not required.
builder.Services.AddDefaultIdentity<IdentityUser>(options =>
    {
        options.SignIn.RequireConfirmedAccount = false;
        options.Lockout.MaxFailedAccessAttempts = 5;
        options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(10);
    })
    .AddRoles<IdentityRole>()
    .AddEntityFrameworkStores<ApplicationDbContext>();

builder.Services.AddAuthorization(options =>
{
    options.AddPolicy("AdminOnly", policy => policy.RequireRole(SeedData.AdminRole));
});

builder.Services.AddRazorPages(options =>
{
    // Every admin page requires the Admin role. Add new page folders here.
    options.Conventions.AuthorizePage("/Index", "AdminOnly");
    options.Conventions.AuthorizeFolder("/Customers", "AdminOnly");
    options.Conventions.AuthorizeFolder("/Gallery", "AdminOnly");

    // No public sign-up: only an admin can open the Register page.
    options.Conventions.AuthorizeAreaPage("Identity", "/Account/Register", "AdminOnly");
});

builder.Services.AddScoped<IPhotoStorage, PhotoStorage>();

var app = builder.Build();

// Apply pending migrations and make sure the admin role/account exist.
using (var scope = app.Services.CreateScope())
{
    var db = scope.ServiceProvider.GetRequiredService<ApplicationDbContext>();
    await db.Database.MigrateAsync();
    await SeedData.InitializeAsync(scope.ServiceProvider, app.Configuration);
}

if (app.Environment.IsDevelopment())
{
    app.UseMigrationsEndPoint();
}
else
{
    app.UseExceptionHandler("/Error");
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseStaticFiles();

app.UseRouting();

app.UseAuthentication();
app.UseAuthorization();

app.MapRazorPages();

app.Run();
