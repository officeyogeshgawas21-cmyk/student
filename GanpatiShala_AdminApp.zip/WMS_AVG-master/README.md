# Ganpati Shala – Admin Web App

Admin panel for a clay Ganesh idol making school (ASP.NET Core 8, Razor Pages, EF Core, SQL Server, Identity).

## Pages (admin login required)

| Page | What it does |
|------|--------------|
| **Dashboard** (`/`) | Customer count, how many have this year's idol photo, available idols and their total value, recent customers, available idols by size |
| **Customers** (`/Customers`) | Name, address, contact, last year's idol photo and this year's idol photo. Search, paging, add, edit, delete |
| **Gallery** (`/Gallery`) | All idols with photo, size in feet and price. Search, filter (available / sold out), sort by price or size, mark sold out, add, edit, delete |

## First run

```bash
cd WMS_AVG
dotnet ef migrations add AddCustomersAndIdols     # one-time: creates the Customers and Idols tables
dotnet run                                        # applies migrations and creates the admin user
```

Install the EF tool first if needed: `dotnet tool install --global dotnet-ef`

Open the URL shown in the console and sign in with the development admin:

- Email: `admin@ganeshshala.local`
- Password: `Admin@12345`

These come from `SeedAdmin` in `appsettings.Development.json`. **Change them, and never use them in production.**
For a real deployment set your own values with user secrets or environment variables:

```bash
dotnet user-secrets set "SeedAdmin:Email" "you@example.com"
dotnet user-secrets set "SeedAdmin:Password" "<a strong password>"
```

## Notes

- The connection string is in `appsettings.json` (SQL Server LocalDB by default). That file is git-ignored; keep your own copy.
- Uploaded photos are stored in `WMS_AVG/wwwroot/uploads/` (git-ignored). Back this folder up together with the database.
- Photos: JPG, PNG or WebP, up to 5 MB, checked by file signature.
- Public registration is disabled; only a signed-in admin can open the Register page to create more admins.
- New admin pages must be added to the authorization rules in `Program.cs`.
